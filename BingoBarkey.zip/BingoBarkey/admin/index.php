<?php
session_start();
error_reporting(1);
include("connection.php");
if(isset($_POST['log']))
{ if($_POST['id']=="" || $_POST['pwd']=="")
{ $err="fill your id and password first"; }
else 
{$d=mysql_query("select * from user where name='{$_POST['id']}' ");
$row=mysql_fetch_object($d);
$fid=$row->name;
$fpass=$row->pass; 
if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
{$_SESSION['sid']=$_POST['id'];
header('location:home.php'); }
else { $er=" your password is not"; }}
}
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Bingo Bakery Index Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand"><h2 style="font-family: verdana; padding: 10px;">Bingo<em style="font-family: verdana; padding: 10px;">Bakery</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <!--div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.php" style="font-family: verdana;">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="products.php" style="font-family: verdana;">Menu</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php" style="font-family: verdana;">Register</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.php" style="font-family: verdana;">Contact</a>
              </li>
            </ul>
          </div-->
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <div class="owl-banner owl-carousel">
        <div class="banner-item-01">
          <div class="text-content">
            <h4 style="font-family: verdana;"><b>Chocolate Cake</b></h4>
            <h2 style="font-family: verdana;"><b>New Arrivals On Sale</b></h2>
          </div>
        </div>
        <div class="banner-item-02">
          <div class="text-content">
            <h4 style="font-family: verdana;">Cheeses cake</h4>
            <h2 style="font-family: verdana;">New Arrivals On Sale</h2>
            
          </div>
        </div>
        <div class="banner-item-03">
          <div class="text-content">
            <h4 style="font-family: verdana;">Black Forest Cake</h4>
            <h2 style="font-family: verdana;">New Arrivals On Sale</h2>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <div class="latest-products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2 style="font-family: verdana;">Welcome</h2>
              <div id="contact_form" class="col_2" style="text-align: center; margin-top: 5px;">
                <h2 style="margin: 10px; font-family: verdana;">Admin LogIn</h2>
                <center>
                <form method="post" name="contact">
                      <div>
                        <label for="phone" style="font-family: verdana;">Username</label>
                        <input type="text" id="id" name="id" style=" padding:10px; margin-bottom:20px; background-color:#f33f3f; color:white; border-radius: 0px  10px;" />
                    </div>
                    <div>
                        <label for="email" style="font-family: verdana;">Password</label>
                        <input type="password" id="pwd" name="pwd" class="validate-email required" style=" padding:10px; margin-bottom:20px; background-color:#f33f3f; color:white; border-radius:0px 10px"/>
                    </div>
              
                     
                    <div></div>
                    
                     <input type="submit" name="log"  id="log" value="Log in" />
                </form>
</center>
            </div>    	
            </div>
          </div>
          
          <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright &copy; 2020 Sixteen Clothing Co., Ltd.
            
            - Design: <a rel="nofollow noopener" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


            

    
    


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
