<?php
session_start();
if($_SESSION['sid']=="")
{
  header('location:index.php');
}
else
{
  ?>
  <?php
  error_reporting(1);
  include("connection.php");
  $img = $_FILES['img']['name'];
  $prono= $_POST['t1'];
  $price= $_POST['t2'];
  if($_POST['sub'])
  {
    $qry="INSERT INTO item(img,prod_no,price) VALUES('$img','$prono','$price')";
    $result=mysql_query($qry) or die ("save items query fail.");
    if($result)
    {
      mkdir("image/$i");
      move_uploaded_file($_FILES['img']['tmp_name'],"image/$i".$_FILES['img']['name']);
      $err="<font size='+2'>item inserted successfully</font>";
    }
    else
    {
        echo "item is not inserted.";
    }
  }
mysql_close($con);

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Bingo Barkey Insert Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--

TemplateMo 546 Sixteen Clothing

https://templatemo.com/tm-546-sixteen-clothing

-->

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-sixteen.css">
    <link rel="stylesheet" href="assets/css/owl.css">

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2 style="font-family: verdana;">Bingo <em style="font-family: verdana;">Bakery</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="home.php" style="font-family: verdana;">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item active">
                <a class="nav-link" href="insert.php" style="font-family: verdana;">Insert</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="viewproduct.php" style="font-family: verdana;">Product</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="vieworder.php" style="font-family: verdana;">Order</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="viewfeedback.php" style="font-family: verdana;">Feedback</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout.php" style="font-family: verdana;">Logout</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <div class="page-heading products-heading header-text">
    <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4 style="font-family: verdana;"><b></b></h4>
              <h2 style="font-family: verdana;"><b>Welcome to Insert Page</b></h2>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div class="products">
      <div class="container">
      
      <h2 style="margin-bottom: 60px;">Insert Image</h2>
                
                <form  name="testform" method="post" enctype="multipart/form-data" >
              <table align="left" style="margin-bottom: 80px;">
                
                    
                
                 <tr>
                    <td height="20px"></td>
                </tr>	
                <tr>
                <td><span>Image:</span></td>
                <td>
                  <input name="img" type="file">
                </td>
                </tr>
                 <tr>
                    <td height="20px"></td>
                </tr>			
                
                <tr>
                  <td><span>product name: </span></td>
                  <td><label>
                  <input name="t1" type="text" id="t1" style="display: block; padding:5px; background-color:#f33f3f; color:white; border-radius: 0px 10px;">
                  </label></td>
                </tr>
                 <tr>
                    <td height="20px"></td>
                </tr>			
                
                <tr>
                  <td><span class="style3">Price:</span></td>
                  <td><label>
                  <input name="t2" type="text" id="t2" style="display: block; padding:5px; background-color:#f33f3f; color:white; border-radius: 0px 10px;">
                  </label></td>
                </tr>
                 <tr>
                    <td height="20px"></td>
                </tr>			
                
                
                
                
                <tr>
                <td  colspan="2" align="center">
                  <input name="sub" type="submit" value="Submit">
                  
                </td>
                </tr>
                
              </table>
              </form>
                <h2><?php echo $err;?></h2>

                    </div> 
               
        
    
    
    

    <?php }  ?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/slick.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
