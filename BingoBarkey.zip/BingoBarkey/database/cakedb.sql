-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 30, 2023 at 09:14 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cakedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `contenttable`
--

CREATE TABLE IF NOT EXISTS `contenttable` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `contenttable`
--

INSERT INTO `contenttable` (`id`, `name`, `email`, `phone`, `message`) VALUES
(1, 'kyaw', 'k@gmail.com', '09786666444', 'hello'),
(7, 'KyawMin', 'g@gmail.com', '09123876944', 'Hi'),
(22, 'min', 'min@gmail.com', '0976654990', 'leeeeeeeeeeeeeeeeeee'),
(23, 'Zero', 'zero@gmail.com', '090000000', 'Good Website');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `img` varchar(40) NOT NULL,
  `prod_no` varchar(40) NOT NULL,
  `price` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `img`, `prod_no`, `price`) VALUES
(15, 'product_01.jpg', 'Chocolate Cake', '22000kyats'),
(16, 'product_02.jpg', 'BlueBerry Cake', '45000kyats'),
(17, 'product_03.jpg', 'Cheeses Cake', '25000kyats'),
(18, 'product_04.jpg', 'Brooklyn Cake', '50000kyats'),
(19, 'product_05.jpg', 'Black Forest Cake', '55000kyats'),
(20, 'product_06.jpg', 'Red Velvet Cake', '55000kyats');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ord_id` int(11) NOT NULL AUTO_INCREMENT,
  `productno` varchar(40) NOT NULL,
  `price` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` varchar(40) NOT NULL,
  `order_no` varchar(30) NOT NULL,
  PRIMARY KEY (`ord_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ord_id`, `productno`, `price`, `name`, `phone`, `address`, `order_no`) VALUES
(1, 'Chocolate Cake', '22000kyats', 'Neo', '09791584348', 'Yangon', 'ord209'),
(2, 'Chocolate Cake', '22000kyats', 'Nn', '09343434343', 'Yango', 'ord299'),
(3, 'BlueBerry Cake', '45000kyats', 'Min MIn', '98199', 'Yangon', 'ord500'),
(4, 'Cheeses Cake', '25000kyats', 'Boninn', '05832122', 'Bago', 'ord411'),
(5, 'Brooklyn Cake', '50000kyats', 'ZZ', '0977667555', 'Hpa an', 'ord401');

-- --------------------------------------------------------

--
-- Table structure for table `registrater`
--

CREATE TABLE IF NOT EXISTS `registrater` (
  `id` int(10) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `country` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrater`
--

INSERT INTO `registrater` (`id`, `name`, `email`, `password`, `phone`, `city`, `country`) VALUES
(0, 'VeVe', 've123@gmail.com', 've123', '09566112233', 'Bago', 'Myanmar'),
(0, 'bobo', 'bo@gmail.com', 'bo123', '0912345678', 'Yangon', 'Myanmar'),
(0, '', '', '', '', '', ''),
(0, 'bobo', 'bo@gmail.com', 'bo123', '0912345678', 'Yangon', 'Myanmar'),
(0, 'bbb', '', '', '', '', ''),
(0, 'noenoe', 'noenoe@gmail.com', 'noe123', '09888783333', 'bago', 'Myanmar'),
(0, 'CoCo', 'co@gmail.com', 'co123', '0989976443', 'Taunggyi', 'Myanmar'),
(0, 'Neo', 'neo@gmail.com', 'neo123', '09332343422', 'minbu', 'Myanmar'),
(0, 'Zero', 'zero@gmail.com', 'zero123', '0900000000', 'Tokyo', 'Japan');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(30) NOT NULL,
  `pass` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `pass`) VALUES
('admin', 1234);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
